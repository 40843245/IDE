
rootProject.name = "IntelliJ_Kotlin_Lincheck_test_v1"

